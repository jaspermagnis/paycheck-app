# Global Paycheck Calculator

A comprehensive, production-ready paycheck calculator platform supporting 100+ countries worldwide. Built with React, TypeScript, Node.js, Express, and PostgreSQL.

## Features

### Core Calculator
- Calculate net salary for any country worldwide
- Support for multiple pay frequencies (weekly, bi-weekly, monthly, annually)
- Detailed tax breakdowns (federal, regional, social security)
- Pre-tax and post-tax deduction handling
- Charts and visualizations for income distribution
- Download, print, and copy results

### Countries Supported
- United States (US)
- United Kingdom (UK)
- Canada (CA)
- Australia (AU)
- Germany (DE)
- France (FR)
- India (IN)
- Brazil (BR)
- Japan (JP)
- China (CN)
- Mexico (MX)
- Singapore (SG)
- South Africa (ZA)
- United Arab Emirates (AE)
- Switzerland (CH)
- And 100+ more countries

### Admin Dashboard
- JWT authentication
- View usage statistics and trends
- Manage tax slabs and rates
- Manage blog posts
- View and respond to contact messages
- Country management

### Blog System
- Full blog functionality with categories and tags
- SEO-optimized posts with meta tags
- Related posts suggestions
- Admin interface for content management

### SEO Features
- Schema.org structured data
- Open Graph meta tags
- Twitter Card support
- Canonical URLs
- FAQ structured data

## Tech Stack

### Frontend
- React 19
- TypeScript
- Vite
- Tailwind CSS 3.4
- shadcn/ui components
- React Router DOM
- Recharts for visualizations
- html2canvas & jsPDF for downloads

### Backend
- Node.js
- Express
- TypeScript
- PostgreSQL
- Sequelize ORM
- JWT authentication
- bcryptjs for password hashing
- express-rate-limit for rate limiting
- helmet for security headers

## Project Structure

```
/
├── app/                    # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── contexts/       # React contexts (Auth, Theme)
│   │   ├── pages/          # Page components
│   │   │   └── admin/      # Admin pages
│   │   ├── services/       # API services
│   │   ├── types/          # TypeScript types
│   │   └── utils/          # Utility functions
│   └── package.json
│
├── backend/                # Backend Node.js application
│   ├── src/
│   │   ├── config/         # Database configuration
│   │   ├── controllers/    # Route controllers
│   │   ├── middleware/     # Express middleware
│   │   ├── models/         # Sequelize models
│   │   ├── routes/         # API routes
│   │   ├── services/       # Business logic
│   │   ├── types/          # TypeScript types
│   │   └── database/       # Seeders and migrations
│   └── package.json
│
└── README.md
```

## Getting Started

### Prerequisites
- Node.js 20+
- PostgreSQL 14+
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd paycheck-calculator
```

2. Install frontend dependencies:
```bash
cd app
npm install
```

3. Install backend dependencies:
```bash
cd ../backend
npm install
```

4. Set up environment variables:

Frontend (`.env`):
```env
VITE_API_URL=http://localhost:5000/api
```

Backend (`.env`):
```env
NODE_ENV=development
PORT=5000

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=paycheck_calculator
DB_USER=postgres
DB_PASSWORD=your_password

# JWT
JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRES_IN=24h

# Admin
ADMIN_DEFAULT_EMAIL=admin@paycheckcalculator.com
ADMIN_DEFAULT_PASSWORD=change_this_password

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

5. Set up the database:
```bash
# Create the database
createdb paycheck_calculator

# Run seeders
npm run seed
```

6. Start the development servers:

Backend:
```bash
npm run dev
```

Frontend (in a new terminal):
```bash
cd ../app
npm run dev
```

7. Access the application:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- Admin Login: http://localhost:5173/admin/login

## Adding a New Country

To add support for a new country:

1. Add the country to the database:
```sql
INSERT INTO countries (code, name, currency_code, currency_symbol, region, has_federal_tax, has_regional_tax, pay_periods)
VALUES ('XX', 'Country Name', 'XXX', '$', 'Region', true, false, '{"weekly": 52, "biweekly": 26, "monthly": 12, "annually": 1}');
```

2. Add tax slabs for the country:
```sql
INSERT INTO tax_slabs (country_code, tax_type, year, min_income, max_income, rate)
VALUES 
  ('XX', 'federal', 2024, 0, 50000, 0.10),
  ('XX', 'federal', 2024, 50000, 100000, 0.20),
  ('XX', 'federal', 2024, 100000, null, 0.30);
```

3. Implement the tax calculation in `backend/src/services/taxCalculator.ts`:
```typescript
private async calculateCountryTaxes(grossAnnual: number, preTaxDeductions: number): Promise<TaxBreakdown> {
  // Implementation
}
```

4. Add the case in the main calculate switch statement.

## Updating Tax Rates

To update tax rates for a country:

1. Log in to the admin dashboard
2. Navigate to Tax Slabs
3. Update existing slabs or add new ones
4. Changes take effect immediately

Or via SQL:
```sql
UPDATE tax_slabs 
SET rate = 0.15 
WHERE country_code = 'US' 
  AND tax_type = 'federal' 
  AND year = 2024 
  AND min_income = 0;
```

## Deployment

### Frontend Build
```bash
cd app
npm run build
```

### Backend Build
```bash
cd backend
npm run build
```

### Environment Variables for Production
- Set `NODE_ENV=production`
- Use strong JWT secret
- Configure PostgreSQL connection
- Set up proper CORS origins
- Enable SSL/TLS

## API Documentation

### Calculator Endpoints
- `POST /api/calculator/calculate` - Calculate paycheck
- `GET /api/calculator/countries` - List all countries
- `GET /api/calculator/countries/:code` - Get country details
- `GET /api/calculator/tax-slabs/:countryCode` - Get tax slabs

### Auth Endpoints
- `POST /api/auth/login` - Admin login
- `GET /api/auth/profile` - Get user profile
- `POST /api/auth/change-password` - Change password

### Blog Endpoints
- `GET /api/blog` - List blog posts
- `GET /api/blog/slug/:slug` - Get post by slug
- `POST /api/blog` - Create post (admin)
- `PUT /api/blog/:id` - Update post (admin)
- `DELETE /api/blog/:id` - Delete post (admin)

### Admin Endpoints
- `GET /api/admin/dashboard-stats` - Dashboard statistics
- `GET /api/admin/usage-stats` - Usage statistics
- `POST /api/admin/tax-slabs` - Create tax slab
- `PUT /api/admin/tax-slabs/:id` - Update tax slab
- `DELETE /api/admin/tax-slabs/:id` - Delete tax slab

## Security Features

- JWT authentication for admin routes
- Password hashing with bcryptjs
- Rate limiting on API endpoints
- Helmet security headers
- Input validation and sanitization
- CORS configuration
- SQL injection protection via Sequelize

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - see LICENSE file for details

## Disclaimer

Tax calculations are estimates based on current rates and may not reflect your exact tax liability. Always consult a qualified tax professional for personalized advice.
