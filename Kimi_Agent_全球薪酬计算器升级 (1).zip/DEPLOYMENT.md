# Deployment Guide

This guide covers deploying the Global Paycheck Calculator to production.

## Prerequisites

- A server with Node.js 20+ installed
- PostgreSQL database
- Domain name (optional but recommended)
- SSL certificate (Let's Encrypt recommended)

## Option 1: Traditional VPS Deployment

### 1. Server Setup

Update your server:
```bash
sudo apt update && sudo apt upgrade -y
```

Install Node.js:
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

Install PostgreSQL:
```bash
sudo apt install postgresql postgresql-contrib -y
```

Install PM2 for process management:
```bash
sudo npm install -g pm2
```

### 2. Database Setup

Create database and user:
```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE paycheck_calculator;
CREATE USER pcuser WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE paycheck_calculator TO pcuser;
\q
```

### 3. Application Deployment

Clone the repository:
```bash
git clone <repository-url>
cd paycheck-calculator
```

Build the frontend:
```bash
cd app
npm install
npm run build
```

Build the backend:
```bash
cd ../backend
npm install
npm run build
```

Create production environment file:
```bash
nano .env
```

```env
NODE_ENV=production
PORT=5000

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=paycheck_calculator
DB_USER=pcuser
DB_PASSWORD=your_secure_password

# JWT (use a strong random string)
JWT_SECRET=your_super_secret_random_string_min_32_chars
JWT_EXPIRES_IN=24h

# Admin
ADMIN_DEFAULT_EMAIL=admin@yourdomain.com
ADMIN_DEFAULT_PASSWORD=your_secure_admin_password

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Frontend URL (for CORS)
FRONTEND_URL=https://yourdomain.com
```

Run database seeders:
```bash
npm run seed
```

Start the backend with PM2:
```bash
pm2 start dist/server.js --name "paycheck-api"
pm2 save
pm2 startup
```

### 4. Nginx Setup

Install Nginx:
```bash
sudo apt install nginx -y
```

Create Nginx configuration:
```bash
sudo nano /etc/nginx/sites-available/paycheck-calculator
```

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    # Frontend
    location / {
        root /path/to/paycheck-calculator/app/dist;
        try_files $uri $uri/ /index.html;
        add_header Cache-Control "public, max-age=31536000, immutable";
    }

    # API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/paycheck-calculator /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 5. SSL Certificate (Let's Encrypt)

Install Certbot:
```bash
sudo apt install certbot python3-certbot-nginx -y
```

Obtain certificate:
```bash
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Auto-renewal is set up automatically.

## Option 2: Docker Deployment

### 1. Create Dockerfile for Backend

```dockerfile
# backend/Dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 5000

CMD ["node", "dist/server.js"]
```

### 2. Create docker-compose.yml

```yaml
version: '3.8'

services:
  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: paycheck_calculator
      POSTGRES_USER: pcuser
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

  backend:
    build: ./backend
    environment:
      NODE_ENV: production
      DB_HOST: db
      DB_PORT: 5432
      DB_NAME: paycheck_calculator
      DB_USER: pcuser
      DB_PASSWORD: ${DB_PASSWORD}
      JWT_SECRET: ${JWT_SECRET}
    depends_on:
      - db
    restart: unless-stopped

  frontend:
    image: nginx:alpine
    volumes:
      - ./app/dist:/usr/share/nginx/html:ro
      - ./nginx.conf:/etc/nginx/conf.d/default.conf:ro
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - backend
    restart: unless-stopped

volumes:
  postgres_data:
```

### 3. Deploy with Docker Compose

```bash
docker-compose up -d
```

## Option 3: Platform-as-a-Service (PaaS)

### Heroku Deployment

1. Create Heroku apps:
```bash
heroku create paycheck-calculator-api
heroku create paycheck-calculator-web
```

2. Add PostgreSQL addon:
```bash
heroku addons:create heroku-postgresql:mini -a paycheck-calculator-api
```

3. Set environment variables:
```bash
heroku config:set JWT_SECRET=your_secret -a paycheck-calculator-api
heroku config:set NODE_ENV=production -a paycheck-calculator-api
```

4. Deploy backend:
```bash
cd backend
git init
git add .
git commit -m "Initial commit"
git push heroku main
```

5. Deploy frontend:
```bash
cd ../app
npm run build
# Use heroku-static or serve via CDN
```

### Railway/Render Deployment

Both platforms support:
- Automatic deployments from Git
- Managed PostgreSQL
- Environment variable configuration
- Custom domains

Follow their respective documentation for Node.js deployments.

## Post-Deployment Checklist

- [ ] Verify API is accessible
- [ ] Test calculator functionality
- [ ] Check admin login works
- [ ] Verify database connections
- [ ] Test SSL certificate
- [ ] Set up monitoring (optional)
- [ ] Configure backups for database
- [ ] Set up log rotation

## Monitoring

### PM2 Monitoring
```bash
pm2 monit
```

### View Logs
```bash
pm2 logs paycheck-api
```

### Nginx Logs
```bash
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

## Backup Strategy

### Database Backup

Create backup script:
```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -U pcuser paycheck_calculator > /backups/paycheck_$DATE.sql
find /backups -name "paycheck_*.sql" -mtime +7 -delete
```

Add to crontab:
```bash
0 2 * * * /path/to/backup.sh
```

## Updates

To update the application:

1. Pull latest changes:
```bash
git pull origin main
```

2. Rebuild:
```bash
cd app && npm run build
cd ../backend && npm run build
```

3. Restart:
```bash
pm2 restart paycheck-api
```

## Troubleshooting

### Common Issues

1. **Database connection errors**
   - Check PostgreSQL is running: `sudo systemctl status postgresql`
   - Verify credentials in .env file
   - Check firewall rules

2. **API not responding**
   - Check PM2 status: `pm2 status`
   - View logs: `pm2 logs paycheck-api`
   - Verify port is not in use: `sudo lsof -i :5000`

3. **Frontend not loading**
   - Check Nginx configuration: `sudo nginx -t`
   - Verify build files exist in dist folder
   - Check Nginx error logs

4. **CORS errors**
   - Verify FRONTEND_URL in backend .env
   - Check CORS configuration in server.ts

## Support

For deployment issues, please:
1. Check the logs first
2. Verify all environment variables are set
3. Ensure database is accessible
4. Check firewall and security group settings
