import React, { useEffect, useState, useContext } from 'react';
import { 
  Calculator, 
  Globe, 
  TrendingUp, 
  Shield, 
  ArrowRight, 
  CheckCircle,
  Sparkles,
  Zap,
  BarChart3,
  Users,
  Clock,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { calculatorApi } from '@/services/api';
import type { Country } from '@/types';
import SEO from '@/components/SEO';
import { RouterContext } from '@/App';

const Home: React.FC = () => {
  const [countries, setCountries] = useState<Country[]>([]);
  const { setCurrentPage } = useContext(RouterContext);

  useEffect(() => {
    fetchCountries();
  }, []);

  const fetchCountries = async () => {
    try {
      const response = await calculatorApi.getCountries();
      setCountries(response.data.slice(0, 12));
    } catch (error) {
      console.error('Failed to fetch countries:', error);
    }
  };

  const features = [
    {
      icon: <Globe className="h-6 w-6" />,
      title: 'Global Coverage',
      description: 'Calculate paychecks for 100+ countries with accurate local tax rules and regulations.',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: <TrendingUp className="h-6 w-6" />,
      title: 'Detailed Breakdown',
      description: 'Get comprehensive tax breakdowns including federal, state, and social contributions.',
      color: 'from-emerald-500 to-teal-500',
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: 'Accurate & Current',
      description: 'Tax rates updated regularly to reflect current year legislation and changes.',
      color: 'from-violet-500 to-purple-500',
    },
    {
      icon: <Calculator className="h-6 w-6" />,
      title: 'Multiple Frequencies',
      description: 'View results weekly, bi-weekly, monthly, or annually based on your needs.',
      color: 'from-orange-500 to-amber-500',
    },
  ];

  const stats = [
    { value: '100+', label: 'Countries', icon: Globe },
    { value: '1M+', label: 'Calculations', icon: BarChart3 },
    { value: '50K+', label: 'Users', icon: Users },
    { value: '99.9%', label: 'Accuracy', icon: Award },
  ];

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Global Paycheck Calculator',
    description: 'Calculate your net salary, taxes, and deductions accurately for any country worldwide.',
    url: 'https://paycheckcalculator.com',
    potentialAction: {
      '@type': 'SearchAction',
      target: 'https://paycheckcalculator.com/calculator',
      'query-input': 'required',
    },
  };

  return (
    <div className="space-y-0">
      <SEO
        title="Global Paycheck Calculator - Calculate Net Salary & Taxes Worldwide"
        description="Free paycheck calculator for any country. Calculate net salary, tax breakdowns, and deductions. Supports USA, UK, Canada, Australia, and 100+ countries."
        schema={schema}
      />

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 animated-gradient opacity-10" />
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 grid-pattern opacity-50" />
        
        {/* Floating Blobs */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-blob float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/20 rounded-full blur-blob float" style={{ animationDelay: '-3s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-blob" />
        
        {/* Content */}
        <div className="relative z-10 py-20 text-center">
          <Badge 
            variant="secondary" 
            className="mb-6 px-4 py-2 text-sm font-medium bg-primary/10 text-primary border-primary/20 hover:bg-primary/20 cursor-pointer"
            onClick={() => setCurrentPage('calculator')}
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Now supporting 100+ countries worldwide
          </Badge>
          
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
            Calculate Your{' '}
            <span className="text-gradient">Net Salary</span>
            <br />
            <span className="text-foreground">Anywhere in the World</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Accurate paycheck calculations for 100+ countries. Get detailed tax breakdowns, 
            deductions, and take-home pay estimates in seconds.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              className="btn-shine gap-2 rounded-full px-8 py-6 text-lg"
              onClick={() => setCurrentPage('calculator')}
            >
              <Calculator className="h-5 w-5" />
              Start Calculating
              <ArrowRight className="h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="gap-2 rounded-full px-8 py-6 text-lg border-2"
              onClick={() => setCurrentPage('countries')}
            >
              <Globe className="h-5 w-5" />
              Explore Countries
            </Button>
          </div>
          
          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            <span className="flex items-center gap-2 bg-background/80 backdrop-blur px-4 py-2 rounded-full border">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Free forever
            </span>
            <span className="flex items-center gap-2 bg-background/80 backdrop-blur px-4 py-2 rounded-full border">
              <CheckCircle className="h-4 w-4 text-green-500" />
              No registration
            </span>
            <span className="flex items-center gap-2 bg-background/80 backdrop-blur px-4 py-2 rounded-full border">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Bank-grade accuracy
            </span>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-muted-foreground/30 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-muted-foreground/50 rounded-full" />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/30">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 mb-4">
                <stat.icon className="h-6 w-6 text-primary" />
              </div>
              <div className="text-3xl md:text-4xl font-bold text-gradient mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">Features</Badge>
          <h2 className="text-4xl font-bold mb-4">Why Use Our Calculator?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Professional-grade tax calculations with an intuitive interface designed for everyone.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="card-lift group border-0 shadow-lg bg-gradient-to-b from-background to-muted/50">
              <CardHeader>
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Countries Section */}
      <section className="py-24 bg-muted/30">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
          <div>
            <Badge variant="outline" className="mb-4">Global Coverage</Badge>
            <h2 className="text-4xl font-bold">Popular Countries</h2>
          </div>
          <Button 
            variant="outline" 
            className="gap-2 mt-4 md:mt-0 rounded-full"
            onClick={() => setCurrentPage('countries')}
          >
            View All Countries
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {countries.map((country) => (
            <button
              key={country.code}
              onClick={() => setCurrentPage('calculator')}
              className="group p-5 bg-background rounded-2xl border hover:border-primary/50 hover:shadow-xl transition-all text-left"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                  {country.currencySymbol}
                </div>
                <div>
                  <p className="font-semibold group-hover:text-primary transition-colors">{country.name}</p>
                  <p className="text-sm text-muted-foreground">{country.currencyCode}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 dot-pattern opacity-50" />
        <div className="relative">
          <div className="text-center mb-16">
            <Badge variant="outline" className="mb-4">How It Works</Badge>
            <h2 className="text-4xl font-bold mb-4">Simple as 1-2-3</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get your salary breakdown in three easy steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                title: 'Enter Your Details',
                description: 'Input your gross salary, select your country, and add any deductions or allowances.',
                icon: <Zap className="h-6 w-6" />,
              },
              {
                step: '2',
                title: 'We Calculate',
                description: 'Our system applies current tax rates and rules for your specific location.',
                icon: <BarChart3 className="h-6 w-6" />,
              },
              {
                step: '3',
                title: 'Get Results',
                description: 'View detailed breakdowns of taxes, deductions, and net pay instantly.',
                icon: <CheckCircle className="h-6 w-6" />,
              },
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="bg-background rounded-3xl p-8 border shadow-lg hover:shadow-xl transition-shadow">
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-white shadow-lg">
                      {item.icon}
                    </div>
                    <span className="text-5xl font-bold text-muted/30">{item.step}</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
                {index < 2 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                    <ArrowRight className="h-8 w-8 text-muted-foreground/30" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 animated-gradient opacity-5" />
        <div className="max-w-4xl mx-auto text-center relative">
          <div className="bg-background/80 backdrop-blur-xl rounded-3xl p-12 border shadow-2xl">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-purple-500 flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Calculator className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-4xl font-bold mb-4">Ready to Calculate Your Paycheck?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-xl mx-auto">
              Join thousands of users who trust our calculator for accurate salary estimates worldwide.
            </p>
            <Button 
              size="lg" 
              className="btn-shine gap-2 rounded-full px-10 py-6 text-lg"
              onClick={() => setCurrentPage('calculator')}
            >
              <Calculator className="h-5 w-5" />
              Try It Now - It's Free
            </Button>
            <div className="flex flex-wrap justify-center gap-6 mt-8 text-sm text-muted-foreground">
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Takes less than 30 seconds
              </span>
              <span className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                100% secure & private
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
